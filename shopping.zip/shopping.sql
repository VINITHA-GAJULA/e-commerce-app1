create database shopping;
use  shopping;
drop table userdetails;
select * from userdetails;
insert into userdetails values(101, 'Nandyala', 'admin@gmail.com', 'admin', 'admin', 123456789);
