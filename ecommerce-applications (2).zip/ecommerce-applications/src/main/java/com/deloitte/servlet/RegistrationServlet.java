package com.deloitte.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.deloitte.entities.User;
import com.deloitte.util.HibernateHelper;

public class RegistrationServlet extends HttpServlet{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//creating a session variable and assigning it with  the session assciated either the HttpServletRequest
		HttpSession httpSession= req.getSession();
		
		System.out.println("Reached Post() in RegistrationServlet.java");
		
		// Unbinding the data which is present in httpRequest 
		String username = req.getParameter("username");
		String emailID = req.getParameter("emailID");
		String password = req.getParameter("password");
		String phone = req.getParameter("phone");
		String address = req.getParameter("address");
		
		// assigned user details to a POJO
		User u = new User();
		
		//storing all the user details in an object
		u.setName(username);
		u.setEmail(emailID);
		u.setPassword(password);
		u.setPhone(phone);
		u.setPic("image.jpg");
		u.setRole("enduser");
		
		
		//saving the user object(user details) into database
		SessionFactory sf =HibernateHelper.getInstance();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction(); 
		int uId=(int)s.save(u);
		tx.commit();
		
		System.out.println("user save successful? >>> uId"+uId);
		
		if(uId>0)
		{
		httpSession.setAttribute("success","Registration Successful: userId->"+ uId);
		} else {
		httpSession.setAttribute("warning","Registration Not Successful");
			
		}
		resp.sendRedirect("register.jsp"); //response object API
		
	}
}
