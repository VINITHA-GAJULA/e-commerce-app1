package com.deloitte.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.deloitte.entities.User;
import com.deloitte.service.UserService;

@WebServlet(urlPatterns = "/login",description = "this is a login servlet")
public class LoginServlet extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//unbinding the data from req object
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		
		
		//printer writer helps to write or print the content you have on the "white browser area".
		PrintWriter out = resp.getWriter();
		
		//Server side validation
		if(email.isEmpty()) {
			out.println("Email is empty, Empty email is invalid!!");
			return;
		}
		
		//go into DB and check if a record exist with the user entered : email & pwd
		User u=new User();
		
		u.setEmail(email);
		u.setPassword(password);
		
		//calling user service layer
		UserService usvc = new UserService();
		//storing the response from service class in a variable "dbUser"
		User dbUser = usvc.getUserByEmailIDAndPassword(u);
		
		HttpSession httpSession=req.getSession();
			
		//Authentication
			if(null==dbUser) {
				httpSession.setAttribute("warning", "Login failed !!");
				resp.sendRedirect("login.jsp");
				
			} else {
				if("enduser".equalsIgnoreCase(dbUser.getRole())) {
					resp.sendRedirect("homepage.jsp");
				}else if("admin".equalsIgnoreCase(dbUser.getRole())) {
					resp.sendRedirect("admin.jsp");
				}
			}
		
	}
	

}
