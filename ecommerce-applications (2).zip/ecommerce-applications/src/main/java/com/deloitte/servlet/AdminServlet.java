package com.deloitte.servlet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.deloitte.dao.CategoryDAO;
import com.deloitte.dao.ProductDAO;
import com.deloitte.entities.Category;
import com.deloitte.entities.Product;

@MultipartConfig
@WebServlet(urlPatterns = "/adminflow",description = "this is a login servlet")
public class AdminServlet extends HttpServlet {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String operation = req.getParameter("operation");
		HttpSession httpSession=req.getSession();
		
		if("addCategory".equals(operation)) {
			//adding category details to db
			
			//1.unbind
			String caTitle=req.getParameter("catTitle");
			String catDescription= req.getParameter("catDescription");
			
			//2.put the values in an object
			Category c=new Category();
			c.setCaTitle(caTitle);
			c.setCatDescrption(catDescription);
			
			//3.call the dao to save the object into  db
			CategoryDAO cDao = new CategoryDAO();
			int catSave=cDao.saveCategory(c);
			
			if(catSave>0) {
				httpSession.setAttribute("success","Category Saved Successfully. cat ID->"+catSave);
			} else if(catSave==0) {
				httpSession.setAttribute("warning","Category save failed");
			}
			resp.sendRedirect("admin.jsp");
			
		}
		if("addProduct".equals(operation)) {
			//adding product details to db
			//1.unbind
			String productName=req.getParameter("productTitle");
			String productDescription=req.getParameter("productDescription");
			int productPrice=Integer.parseInt(req.getParameter("productPrice"));
			int productDiscount=Integer.parseInt(req.getParameter("productDiscount"));
			int productQty=Integer.parseInt(req.getParameter("productQty"));
			
			//It is the id of the category selected by user in the front end 
			int catId=Integer.parseInt(req.getParameter("catId"));
			
			CategoryDAO cDao=new CategoryDAO();
			Category c=cDao.getCategoryById(catId);
			
			//2.prepare product object to be saved into db by hibernate
			Product p= new Product();
			
			p.setProductDescription(productDescription);
			p.setProductName(productName);
			p.setProductPrice(productPrice);
			p.setProductDiscount(productDiscount);
			p.setProductQty(productQty);
			p.setCategory(c);
			
			//retrive the product image element data using "part"
			Part part=req.getPart("productImage");
			//create a path where you want to store the image uploaded by User-On the server
			String imgPath= req.getServletContext().getRealPath("images")+ "/products/"+part.getSubmittedFileName();
			
			
			//Do some file(stream of data:bytes-read write operations
			InputStream is=part.getInputStream(); 
			FileOutputStream fos = new FileOutputStream(imgPath);//create a fos to create a file in the specified path
			byte[] data=new byte[is.available()];// create a byte array- the size of the image(in terms of a bytes)
			
			is.read(data);//readig the bytes from input stream
			
			fos.write(data);//writing the bytes to an output stream->ideally to a file
			
			//setting the product image"file name" to the product object
			p.setProductImage(part.getSubmittedFileName());
			
			//3.save the product into db
			ProductDAO pDao = new ProductDAO();
			int pId=pDao.saveProduct(p);
			
			if(pId>0) {
				httpSession.setAttribute("success","Product Saved Successfully. pId->"+pId);
			} else if(pId==0) {
				httpSession.setAttribute("warning","Product save failed");
			}
			resp.sendRedirect("admin.jsp");
			
		}
	}
	
}
