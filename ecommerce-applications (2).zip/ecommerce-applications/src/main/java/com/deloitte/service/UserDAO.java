package com.deloitte.service;

import org.hibernate.Session;

import com.deloitte.entities.User;
import com.deloitte.util.HibernateHelper;

public class UserDAO {

	public User getUserByEmailIDAndPassword(User u)
	{
		//write the code to interact with db
		//SessionFactory sf= HibernateHelper.getInstance()
		//Session s= sf.openSession();
		
		Session s= HibernateHelper.getInstance().openSession();
		
		//write a HQL command: hibernate query language
		String query = "from User where email =: param1 and password =: param2"; //command to db
		
		//String query1= "from User where email=:"+u.getEmail()+"and password=:"+u.getPassword();
		
		//hibernate session API(createQuery) to execute the command
		User userObjFromDB = (User)s.createQuery(query).
				setParameter("param1", u.getEmail()).
				setParameter("param2", u.getPassword()).uniqueResult();
		return userObjFromDB;
		
		
	}
}
