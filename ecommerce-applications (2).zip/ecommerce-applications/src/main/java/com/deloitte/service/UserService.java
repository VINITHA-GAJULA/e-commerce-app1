package com.deloitte.service;

import com.deloitte.entities.User;

public class UserService {

	

	public User getUserByEmailIDAndPassword(User u) {
		
		UserDAO udao = new UserDAO();
		User user= udao.getUserByEmailIDAndPassword(u);
		
		return user;
	}
}
