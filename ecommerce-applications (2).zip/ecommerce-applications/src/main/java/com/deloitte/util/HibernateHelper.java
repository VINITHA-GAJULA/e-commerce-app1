package com.deloitte.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateHelper {
	
	private static SessionFactory sf; //null
	
	public static SessionFactory getInstance() {
		
		//creation of SessionFactory object "sf" is very expensive operation- with respect to PERFOMANCE
	
		// singleton pattern
		
		if(sf == null) 
	{
		sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	}
		return sf;
	}
}