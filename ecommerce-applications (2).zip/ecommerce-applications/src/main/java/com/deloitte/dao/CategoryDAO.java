package com.deloitte.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.deloitte.entities.Category;
import com.deloitte.util.HibernateHelper;

public class CategoryDAO {

	public int saveCategory(Category c) {
	
		//1.get instance of session factory
	SessionFactory sf=HibernateHelper.getInstance();
	
	//2.get instance from (hibernate)session from sf
	Session s=sf.openSession();
	
	//3.
	Transaction tx=s.beginTransaction();
	
	int dbResult=(int) s.save(c);
	
	tx.commit();
	
	s.close();
	
	return dbResult;
}
	public List<Category> fetchAllCategories() {
		
		SessionFactory sf = HibernateHelper.getInstance();
		
		//get instance of session from sf
		Session s=sf.openSession();
		
		Query<Category> q=s.createQuery("from Category", Category.class);
		
		List<Category> catList=q.getResultList();
		s.close();
		
		return catList;
	}
	
	public Category getCategoryById(int catId) {
		
		SessionFactory sf = HibernateHelper.getInstance();
		Session s=sf.openSession();
		
		Category c=s.get(Category.class,catId);
		
		s.close();
		return c;
		
	}
}