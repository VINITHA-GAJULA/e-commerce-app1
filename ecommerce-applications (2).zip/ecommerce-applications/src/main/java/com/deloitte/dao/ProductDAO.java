package com.deloitte.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.deloitte.entities.Product;
import com.deloitte.util.HibernateHelper;

public class ProductDAO {

	public int saveProduct(Product p) {
		//1.get instance of session factory
		SessionFactory sf=HibernateHelper.getInstance();
		
		//2.get instance from (hibernate)session from sf
		Session s=sf.openSession();
		
		//3.
		Transaction tx=s.beginTransaction();
		
		int dbResult=(int) s.save(p);
		
		tx.commit();
		
		s.close();
		
		return dbResult;
	}
	
}
