package com.deloitte.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="CATEGORY_TB")
public class Category {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="category_title")
	private String caTitle;
	
	@Column(name="category_desc")
	private String catDescrption;
	
	@OneToMany(mappedBy = "category")
	private List<Product> products=new ArrayList<Product>();//ctrl+shift+O : to organize imports in a .java file

	/**
	 * Default Constructor// no arg constructors
	 * 1.constructor is a method with save name as class name
	 * 2.it does not have a return type
	 * 3.this is the first method that will be  invalid when you / JVM create an object
	 * 4.creating an object: new <constructor()> 
	 * @return
	 */
	
	
	public Category() {
		
	}
	//static polymorphism: compile time polymorphism(overloading)
	public Category(String name) {
		this();
		
	}
	
	
	//generate getters and setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCaTitle() {
		return caTitle;
	}

	public void setCaTitle(String caTitle) {
		this.caTitle = caTitle;
	}

	public String getCatDescrption() {
		return catDescrption;
	}

	public void setCatDescrption(String catDescrption) {
		this.catDescrption = catDescrption;
	}

	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	
	//generate toString()
	@Override
	public String toString() {
		return "Category [id=" + id + ", caTitle=" + caTitle + ", catDescrption=" + catDescrption + ", products="
				+ products + "]";
	}
	
	
}
