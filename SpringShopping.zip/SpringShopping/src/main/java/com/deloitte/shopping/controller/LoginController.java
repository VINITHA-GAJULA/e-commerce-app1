package com.deloitte.shopping.controller;

import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestParam;

import com.deloitte.shopping.entities.Category;
import com.deloitte.shopping.entities.Product;
import com.deloitte.shopping.entities.Register;
import com.deloitte.shopping.service.UserService;

@Controller
public class LoginController {

	@Autowired
	UserService Userv;

	// retriving view
	@GetMapping("/login")
	public String showLoginPage() {
		return "login";
	}

	// method findByEmailAndPassword to check dtails
	@PostMapping("/loginDetails")
	public String findByEmailAndPassword(@RequestParam String userEmail, @RequestParam String userPassword,
			ModelMap model) {
		Register reg = Userv.findByEmailAndPassword(userEmail, userPassword);
		System.out.println("redgg:"+reg);

//Here,it checks incorrect details,role & acc to role it returns to respective jsp
		if (reg == null) {
			model.addAttribute("errorMsg", "Incorrect email or password");
			return "login";
		} else if (reg.getRole().equals("admin")) {
			return "admin";
		} else

			// welcome along with username
			model.addAttribute("userName", reg.getUserName());

		// list of products and categories to home page
		List<Category> a = Userv.findAllCategory();
		List<Product> l = Userv.getAllProducts();
		model.addAttribute("catdetails", a);
		model.addAttribute("prddetails", l);
		return "home";
		}

	}

