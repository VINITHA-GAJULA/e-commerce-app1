package com.deloitte.shopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.deloitte.shopping.entities.Product;
import com.deloitte.shopping.service.UserService;

@Controller
public class CartController {
	@Autowired
	UserService Userv;

	@GetMapping("/cart")
	public String getCartPage() {
		return "cart";
	}

	@GetMapping("getproduct")
	public String getProducts(ModelMap model) {
		// Product pp = new Product();
		List<Product> pp = Userv.getAllProducts();
		System.out.println("cart" + pp);
		model.addAttribute("catdetails", pp);
		return "cart";

	}

}
