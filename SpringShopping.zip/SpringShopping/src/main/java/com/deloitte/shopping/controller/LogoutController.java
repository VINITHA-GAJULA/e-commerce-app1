package com.deloitte.shopping.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LogoutController {

	@GetMapping("/logout")
	// method takes 2 parameters http obj,these obj allow method to interact with
	// the req,res bw c and server
	public String logout(HttpServletRequest req, HttpServletResponse rep) {
		HttpSession session = req.getSession(false);
		// current session associated with req, if no the getsession return null, false
		// method should not create a new session if exist
		if (session != null) {
			session.invalidate();
			// if a session exists this line invalidates it, which removes all attributes
			// associated with session
		}
		return "login";

	}
}
