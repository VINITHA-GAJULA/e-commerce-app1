package com.deloitte.shopping.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.deloitte.shopping.entities.Register;

public interface RegisterDAO extends CrudRepository<Register, Long> 

{
//nativeQuery 
	@Query(value ="select * from userdetails r where  r.user_email = :user_email and user_password=:user_Password",  nativeQuery = true )
	 
	Register findByEmailAndPassword(@Param("user_email")String userEmail,@Param("user_Password")String userPassword);
		}