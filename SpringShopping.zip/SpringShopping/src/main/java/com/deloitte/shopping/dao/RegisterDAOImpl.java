package com.deloitte.shopping.dao;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.deloitte.shopping.model.Register;

@Repository
public class RegisterDAOImpl {
	
	@Autowired
	JdbcTemplate jdbc;
	static int count =0;
	 public int findByEmail(String email, String password)
	 {
		 String sql="select * from userdetails where user_email = '"+email+"' and user_password = '"+password+"' ";
	
		 jdbc.query(sql, new RowMapper<Register>() {

			@Override
			public Register mapRow(ResultSet rs, int rowNum) throws SQLException {
				System.out.println(rs.next());
//				while(rs.next()) {
//					
//				}
				Register reg = new Register();
//				reg.setId(rs.getLong(1));
//				if(rs.getLong(1)>0) {
					count++;
//				}
				return reg;
			}
			 
		 });
		 if(count>0) {
			 return 1;
		 }
		 else return 0;
	 }

}
