package com.deloitte.shopping.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.shopping.dao.RegisterDAO;
import com.deloitte.shopping.dao.RegisterDAOImpl;
import com.deloitte.shopping.model.Register;

@Service
public class UserService {
	@Autowired
	private RegisterDAO Urepo;

	@Autowired
	public RegisterDAOImpl Rdao;
	
	public Register saveUser(Register r) {
		return Urepo.save(r);
	}

	public int getUserByEmail(String email,String password) { 
		return Rdao.findByEmail(email,password);
	}

	public Register createNewUser(Register reg) { 
		return Urepo.save(reg);
	}

}
