package com.deloitte.shopping.service;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deloitte.shopping.dao.CategoryDAO;
import com.deloitte.shopping.dao.ProductDAO;
import com.deloitte.shopping.dao.RegisterDAO;
import com.deloitte.shopping.entities.Category;
import com.deloitte.shopping.entities.Product;
import com.deloitte.shopping.entities.Register;


@Service
public class UserService {

	// RegisterDAO
	@Autowired
	private RegisterDAO Urepo;

	// CategoryDAO
	@Autowired
	public CategoryDAO Cdao;

	// ProductDAO
	@Autowired
	public ProductDAO Pdao;

	// saving register details in db by using method save
	public Register saveRegister(Register reg) {
				return Urepo.save(reg);
	}

	// email and password method in login controller
	public Register findByEmailAndPassword(String email, String password) {
		return Urepo.findByEmailAndPassword(email, password);
	}

	// category details save
	public Category saveCat(Category cat) {
		return Cdao.save(cat);
	}

//getting list of cat from db
	public List<Category> findAllCategory() {
		List<Category> l = Cdao.findAll();
		return l;
	}

	// product details save
	public Product savePrd(Product prd) {
		return Pdao.save(prd);
	}

	// getting list of products from db
	public List<Product> getAllProducts() {
		List<Product> p = Pdao.findAll();
		System.out.println("PRODUCTDDD:;" + p);

		for (Product prd : p) {
			System.out.println("desc:" + prd.getProductImage());
			byte[] imageData = prd.getProductImage().getBytes();
			System.out.println("image product:" + imageData);
			String imageBase64 = Base64.getEncoder().encodeToString(imageData);
			prd.setProductImage(imageBase64);
			System.out.println("image:" + imageBase64);
			byte[] decodedData = Base64.getDecoder().decode(imageBase64);
			String decodedimage =new String(decodedData,StandardCharsets.UTF_8);
			System.out.println("decode:"+decodedimage);
		}
		return p;

	}



	
}
