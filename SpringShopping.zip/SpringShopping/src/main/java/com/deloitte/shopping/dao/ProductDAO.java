package com.deloitte.shopping.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.deloitte.shopping.entities.Product;


public interface ProductDAO  extends JpaRepository<Product, Long>{
	
}
