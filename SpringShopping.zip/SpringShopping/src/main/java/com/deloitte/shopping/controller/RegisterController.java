package com.deloitte.shopping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;


import com.deloitte.shopping.entities.Register;
import com.deloitte.shopping.service.UserService;

@Controller

public class RegisterController {

	@Autowired
	UserService Userv;

	
	@GetMapping("/register")
	public String getRegisterPage() {
		return "register"; // returns register.jsp page when a get request is made to "/register" URL
	}

	
	// saving details into db
	@PostMapping("/saveRegister")
	public String saveRegisterDetails(@ModelAttribute Register reg, ModelMap model) {
		// Here, method saves the register details in db when post req made to "/saveregister" URL
		// the reg details are passed as a Register object using @ModelAttribute
		// the saved reg is stored in ModelMap and passed to view
		model.addAttribute("message", "Registration Successfull");
		 Userv.saveRegister(reg);
		 return "register";
	}

}
