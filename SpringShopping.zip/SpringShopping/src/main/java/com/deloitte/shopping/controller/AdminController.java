package com.deloitte.shopping.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.deloitte.shopping.entities.Category;
import com.deloitte.shopping.entities.Product;
import com.deloitte.shopping.service.UserService;

@Controller
public class AdminController {

	@Autowired
	UserService Userv;

//getting view of admin jsp page
	@GetMapping("/admin")
	public String AdminPage() {
		return "admin";// view
	}

	// getting view of category
	@GetMapping("/category")
	public String getCategory() {
		return "category";
	}

	// saving category details into database
	@PostMapping("/saveCategory")
	public String saveCategory(@ModelAttribute Category cat, ModelMap model) {
		Userv.saveCat(cat);
		return "admin";

	}

	// getting view of product
	@GetMapping("/product")
	public String getProduct() {
		return "product";
	}

	// saving product details into database
	@PostMapping("/saveProduct")
	public String saveProduct(@ModelAttribute Product prd, ModelMap model) {
		Userv.savePrd(prd);
		return "admin";
	}

}
